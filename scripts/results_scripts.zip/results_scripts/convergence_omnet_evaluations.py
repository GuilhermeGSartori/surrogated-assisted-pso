#!/usr/bin/env python3

"""
Compare the number of OMNeT++ evaluations required by PSO-Sim, Hybrid,
and Naive-Sim to reach 95% of their own final simulation-confirmed improvement.

Operational convergence definition
----------------------------------
For each run:

    target = initial_best
             + fraction * (final_best - initial_best)

where `fraction` is 0.95 by default.

To make the methods comparable, `initial_best` is the best PDR found after
the first `baseline_evals` high-fidelity evaluations. By default:

- PSO-Sim: uses the particle count from the log header when available.
- Hybrid:  uses the particle count from the log header when available.
- Naive-Sim: reconstructs its sparse best-so-far trajectory from
             `ITERATION` + `new best fitness` markers and uses the same
             baseline size as paired PSO-Sim.

The reported convergence cost is the cumulative number of OMNeT++ evaluations
at the first point where the running simulation-confirmed best reaches the
target.

Important interpretation
------------------------
For Naive-Sim, "convergence" is only an operational best-so-far threshold.
Naive random search has no PSO-style convergence dynamics.

Hybrid OMNeT++ detection
------------------------
The current Hybrid logger uses "Resulting Fitness:" for both RF and OMNeT++
evaluations. In the logs used for this project, RF calls take only a few
hundredths of a second while OMNeT++ calls are much slower. Therefore Hybrid
evaluations with:

    Evaluation Time >= --sim-time-threshold

are treated as OMNeT++ evaluations. Default threshold: 0.2 s.

Outputs
-------
- convergence_summary.csv
- convergence_per_run.csv
- LaTeX-ready table rows printed to terminal

Example
-------
python3 convergence_omnet_evaluations.py \
    --pso-sim logs/pso_sim \
    --hybrid logs/hybrid \
    --naive-sim logs/naive_sim \
    --expected 25 \
    --out convergence_analysis
"""

import argparse
import csv
import re
import statistics
import sys
from pathlib import Path


NUM = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?"

ITER_RE = re.compile(
    r"\s*ITERATION:\s+(\d+)\s*",
    re.IGNORECASE,
)

PARTICLES_RE = re.compile(
    r"^\s*Particles:\s*(\d+)",
    re.IGNORECASE | re.MULTILINE,
)

SEED_RE = re.compile(
    r"^\s*Seed:\s*(\d+)",
    re.IGNORECASE | re.MULTILINE,
)

EVAL_TIME_RE = re.compile(
    rf"^\s*Evaluation Time:\s*({NUM})\s*seconds",
    re.IGNORECASE,
)

FITNESS_RE = re.compile(
    rf"^\s*Resulting Fitness:\s*({NUM})",
    re.IGNORECASE,
)

NEW_BEST_RE = re.compile(
    rf"^\s*new best fitness:\s*({NUM})",
    re.IGNORECASE,
)


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def ordered_logs(folder: Path):
    if not folder.is_dir():
        raise ValueError(f"not a directory: {folder}")

    logs = sorted(folder.rglob("*.log"), key=lambda p: (p.name, str(p)))
    if not logs:
        raise ValueError(f"no .log files found under {folder}")
    return logs


def parse_header(text: str):
    pm = PARTICLES_RE.search(text)
    sm = SEED_RE.search(text)

    return {
        "particles": int(pm.group(1)) if pm else None,
        "seed": int(sm.group(1)) if sm else None,
    }


def parse_evaluations(path: Path):
    """
    Extract every evaluation that has both:
        Evaluation Time: X seconds
        Resulting Fitness: Y

    Iteration labels are optional so this also works with Naive-Sim logs
    that may not use PSO iteration markers.
    """
    text = read_text(path)
    header = parse_header(text)

    current_iteration = None
    pending_time = None
    evaluations = []

    for line in text.splitlines():
        m = ITER_RE.search(line)
        if m:
            current_iteration = int(m.group(1))
            pending_time = None
            continue

        m = EVAL_TIME_RE.search(line)
        if m:
            pending_time = float(m.group(1))
            continue

        m = FITNESS_RE.search(line)
        if m:
            fitness = float(m.group(1))

            if not 0.0 <= fitness <= 1.0:
                raise ValueError(
                    f"{path.name}: PDR outside [0,1]: {fitness}"
                )

            if pending_time is None:
                # Ignore fitness lines that are not individual timed evaluations.
                continue

            evaluations.append({
                "iteration": current_iteration,
                "evaluation_time": pending_time,
                "fitness": fitness,
            })
            pending_time = None

    if not evaluations:
        raise ValueError("no timed optimization evaluations found")

    return header, evaluations



def parse_naive_best_events(path: Path):
    """
    Parse sparse Naive-Sim logs.

    Naive-Sim does not log every evaluation with Evaluation Time/Resulting
    Fitness. Instead it records only improvements using:

        -- ITERATION N --
        new best fitness: X

    Because random search evaluates one candidate per iteration, the ITERATION
    number is used as the evaluation index. If the first improvement is at
    ITERATION 0, numbering is treated as zero-based and converted to
    evaluation_count = iteration + 1. Otherwise it is treated as one-based.

    The sparse best-so-far trajectory is sufficient for the 95%-of-final-
    improvement analysis: between two improvement events, the best value is
    unchanged.
    """
    text = read_text(path)
    header = parse_header(text)

    current_iteration = None
    events_raw = []

    for line in text.splitlines():
        m = ITER_RE.search(line)
        if m:
            current_iteration = int(m.group(1))
            continue

        m = NEW_BEST_RE.search(line)
        if m and current_iteration is not None:
            fitness = float(m.group(1))
            if not 0.0 <= fitness <= 1.0:
                raise ValueError(
                    f"{path.name}: PDR outside [0,1]: {fitness}"
                )
            events_raw.append((current_iteration, fitness))

    if not events_raw:
        raise ValueError(
            "no Naive-Sim improvement events found "
            "(expected '-- ITERATION N --' + 'new best fitness: X')"
        )

    # The first candidate always improves an initial -inf best, so if this
    # implementation is zero-based the first event should be iteration 0.
    zero_based = events_raw[0][0] == 0

    events = []
    running_best = float("-inf")
    for iteration, fitness in events_raw:
        evaluation_count = iteration + 1 if zero_based else iteration

        # Ignore accidental duplicate/non-improving markers defensively.
        if fitness + 1e-12 < running_best:
            raise ValueError(
                f"{path.name}: Naive best decreased from {running_best} "
                f"to {fitness} at iteration {iteration}"
            )

        running_best = max(running_best, fitness)
        events.append({
            "iteration": iteration,
            "evaluation_count": evaluation_count,
            "fitness": running_best,
        })

    return header, events


def analyze_naive_run(
    path: Path,
    fraction: float,
    baseline_evals: int,
):
    header, events = parse_naive_best_events(path)

    if baseline_evals < 1:
        raise ValueError("baseline_evals must be >= 1")

    # Reconstruct best-so-far at the end of the common baseline budget.
    baseline_events = [
        e for e in events if e["evaluation_count"] <= baseline_evals
    ]
    if not baseline_events:
        raise ValueError(
            f"no Naive-Sim best event found within first "
            f"{baseline_evals} evaluations"
        )

    initial_best = baseline_events[-1]["fitness"]
    final_best = events[-1]["fitness"]
    improvement = max(0.0, final_best - initial_best)
    target = initial_best + fraction * improvement

    if improvement <= 1e-12:
        convergence_eval = baseline_evals
        convergence_iteration = None
        convergence_fitness = initial_best
    else:
        convergence_event = None
        for e in events:
            if e["evaluation_count"] < baseline_evals:
                continue
            if e["fitness"] + 1e-12 >= target:
                convergence_event = e
                break

        if convergence_event is None:
            raise ValueError(
                f"Naive-Sim never reached convergence target {target}"
            )

        convergence_eval = convergence_event["evaluation_count"]
        convergence_iteration = convergence_event["iteration"]
        convergence_fitness = convergence_event["fitness"]

    total_evaluations = events[-1]["evaluation_count"]

    return {
        "method": "Naive-Sim",
        "log": str(path),
        "filename": path.name,
        "seed": header["seed"],
        "particles_in_header": header["particles"],
        "baseline_evaluations": baseline_evals,
        "all_optimizer_evaluations": total_evaluations,
        "total_omnet_evaluations": total_evaluations,
        "initial_best_pdr": initial_best,
        "final_simulation_confirmed_best_pdr": final_best,
        "total_improvement": improvement,
        "convergence_fraction": fraction,
        "convergence_target_pdr": target,
        "convergence_omnet_evaluations": convergence_eval,
        "convergence_iteration": convergence_iteration,
        "convergence_event_fitness": convergence_fitness,
    }


def select_omnet_evaluations(
    evaluations,
    method: str,
    sim_time_threshold: float,
):
    if method in ("PSO-Sim", "Naive-Sim"):
        selected = list(evaluations)

    elif method == "Hybrid":
        selected = [
            e for e in evaluations
            if e["evaluation_time"] >= sim_time_threshold
        ]

    else:
        raise ValueError(f"unknown method: {method}")

    if not selected:
        raise ValueError(
            f"{method}: no OMNeT++ evaluations detected"
        )

    result = []
    for index, e in enumerate(selected, start=1):
        item = dict(e)
        item["omnet_evaluation"] = index
        result.append(item)

    return result


def analyze_run(
    path: Path,
    method: str,
    fraction: float,
    sim_time_threshold: float,
    baseline_evals: int,
):
    header, all_evals = parse_evaluations(path)

    sim_evals = select_omnet_evaluations(
        all_evals,
        method,
        sim_time_threshold,
    )

    if baseline_evals < 1:
        raise ValueError("baseline_evals must be >= 1")

    if len(sim_evals) < baseline_evals:
        raise ValueError(
            f"{method}: detected only {len(sim_evals)} OMNeT++ evaluations, "
            f"but baseline requires {baseline_evals}"
        )

    first_block = sim_evals[:baseline_evals]
    initial_best = max(e["fitness"] for e in first_block)
    final_best = max(e["fitness"] for e in sim_evals)

    improvement = final_best - initial_best

    if improvement < -1e-12:
        raise ValueError(
            f"{method}: final best ({final_best}) is below initial best "
            f"({initial_best})"
        )

    improvement = max(0.0, improvement)
    target = initial_best + fraction * improvement

    running_best = float("-inf")
    convergence_event = None

    for e in sim_evals:
        running_best = max(running_best, e["fitness"])

        # The baseline itself only exists after this many evaluations.
        if e["omnet_evaluation"] < baseline_evals:
            continue

        if running_best + 1e-12 >= target:
            convergence_event = e
            break

    if convergence_event is None:
        raise ValueError(
            f"{method}: never reached convergence target {target}"
        )

    return {
        "method": method,
        "log": str(path),
        "filename": path.name,
        "seed": header["seed"],
        "particles_in_header": header["particles"],
        "baseline_evaluations": baseline_evals,
        "all_optimizer_evaluations": len(all_evals),
        "total_omnet_evaluations": len(sim_evals),
        "initial_best_pdr": initial_best,
        "final_simulation_confirmed_best_pdr": final_best,
        "total_improvement": improvement,
        "convergence_fraction": fraction,
        "convergence_target_pdr": target,
        "convergence_omnet_evaluations": convergence_event["omnet_evaluation"],
        "convergence_iteration": convergence_event["iteration"],
        "convergence_event_fitness": convergence_event["fitness"],
    }


def summarize(rows):
    values = [r["convergence_omnet_evaluations"] for r in rows]

    return {
        "method": rows[0]["method"],
        "runs": len(values),
        "mean_evaluations": statistics.mean(values),
        "median_evaluations": statistics.median(values),
        "std_deviation": statistics.stdev(values) if len(values) > 1 else 0.0,
        "min_evaluations": min(values),
        "max_evaluations": max(values),
        "mean_total_omnet_evaluations": statistics.mean(
            r["total_omnet_evaluations"] for r in rows
        ),
    }


def write_csv(path: Path, rows, fieldnames):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(
        description=(
            "Compare PSO-Sim, Hybrid, and Naive-Sim OMNeT++ evaluations "
            "required to reach a fraction of their final improvement."
        )
    )

    parser.add_argument(
        "--pso-sim",
        type=Path,
        required=True,
        help="Folder containing PSO-Sim .log files",
    )
    parser.add_argument(
        "--hybrid",
        type=Path,
        required=True,
        help="Folder containing Hybrid .log files",
    )
    parser.add_argument(
        "--naive-sim",
        type=Path,
        required=True,
        help="Folder containing Naive-Sim .log files",
    )
    parser.add_argument(
        "--expected",
        type=int,
        default=None,
        help="Expected number of runs/scenarios for each method",
    )
    parser.add_argument(
        "--fraction",
        type=float,
        default=0.95,
        help="Fraction of final improvement used as convergence threshold (default: 0.95)",
    )
    parser.add_argument(
        "--sim-time-threshold",
        type=float,
        default=0.2,
        help=(
            "Hybrid Evaluation Time threshold, in seconds, used to identify "
            "OMNeT++ evaluations (default: 0.2)"
        ),
    )
    parser.add_argument(
        "--baseline-evals",
        type=int,
        default=20,
        help=(
            "Fallback baseline evaluation count. PSO-Sim and Hybrid use the "
            "particle count in their log header when available. Naive-Sim uses "
            "the paired PSO-Sim baseline size when available. Default: 20"
        ),
    )
    parser.add_argument(
        "--out",
        type=Path,
        default=Path("convergence_analysis"),
        help="Output directory",
    )

    args = parser.parse_args()

    if not 0.0 <= args.fraction <= 1.0:
        parser.error("--fraction must be between 0 and 1")
    if args.baseline_evals < 1:
        parser.error("--baseline-evals must be >= 1")

    pso_logs = ordered_logs(args.pso_sim)
    hybrid_logs = ordered_logs(args.hybrid)
    naive_logs = ordered_logs(args.naive_sim)

    counts = {
        "PSO-Sim": len(pso_logs),
        "Hybrid": len(hybrid_logs),
        "Naive-Sim": len(naive_logs),
    }

    if args.expected is not None:
        for method, count in counts.items():
            if count != args.expected:
                raise SystemExit(
                    f"ERROR: {method} has {count} logs; expected {args.expected}"
                )

    if len(set(counts.values())) != 1:
        raise SystemExit(
            "ERROR: different number of logs: "
            + ", ".join(f"{m}={n}" for m, n in counts.items())
        )

    all_rows = []
    errors = []

    # Same pairing convention as the prior scripts:
    # sorted filename/path order.
    for scenario_number, (pso_path, hybrid_path, naive_path) in enumerate(
        zip(pso_logs, hybrid_logs, naive_logs),
        start=1,
    ):
        try:
            # Read PSO header first so its actual population size can define
            # the common initial high-fidelity budget for the paired scenario.
            pso_header, _ = parse_evaluations(pso_path)
            common_baseline = (
                pso_header["particles"]
                if pso_header["particles"] is not None
                else args.baseline_evals
            )

            pso = analyze_run(
                pso_path,
                "PSO-Sim",
                args.fraction,
                args.sim_time_threshold,
                common_baseline,
            )

            # Hybrid normally has the same particle count; use its own header
            # if available, otherwise the same common baseline.
            hybrid_header, _ = parse_evaluations(hybrid_path)
            hybrid_baseline = (
                hybrid_header["particles"]
                if hybrid_header["particles"] is not None
                else common_baseline
            )

            hybrid = analyze_run(
                hybrid_path,
                "Hybrid",
                args.fraction,
                args.sim_time_threshold,
                hybrid_baseline,
            )

            # Naive has no PSO population concept. Use the same initial
            # high-fidelity evaluation budget as paired PSO-Sim.
            naive = analyze_naive_run(
                naive_path,
                args.fraction,
                common_baseline,
            )

            for row in (pso, hybrid, naive):
                row["scenario_number"] = scenario_number

            seeds = {
                r["method"]: r["seed"]
                for r in (pso, hybrid, naive)
                if r["seed"] is not None
            }
            if len(set(seeds.values())) > 1:
                print(
                    f"WARNING scenario {scenario_number}: seed mismatch: "
                    + ", ".join(f"{m}={s}" for m, s in seeds.items()),
                    file=sys.stderr,
                )

            all_rows.extend([pso, hybrid, naive])

        except Exception as exc:
            errors.append(
                f"scenario {scenario_number}: "
                f"{pso_path.name} / {hybrid_path.name} / {naive_path.name}: {exc}"
            )

    if errors:
        print("\nERRORS:", file=sys.stderr)
        for e in errors:
            print(f"  - {e}", file=sys.stderr)
        raise SystemExit(1)

    method_order = ["PSO-Sim", "Hybrid", "Naive-Sim"]
    summaries = [
        summarize([r for r in all_rows if r["method"] == method])
        for method in method_order
    ]

    args.out.mkdir(parents=True, exist_ok=True)

    per_run_fields = [
        "scenario_number",
        "method",
        "filename",
        "log",
        "seed",
        "particles_in_header",
        "baseline_evaluations",
        "all_optimizer_evaluations",
        "total_omnet_evaluations",
        "initial_best_pdr",
        "final_simulation_confirmed_best_pdr",
        "total_improvement",
        "convergence_fraction",
        "convergence_target_pdr",
        "convergence_omnet_evaluations",
        "convergence_iteration",
        "convergence_event_fitness",
    ]

    summary_fields = [
        "method",
        "runs",
        "mean_evaluations",
        "median_evaluations",
        "std_deviation",
        "min_evaluations",
        "max_evaluations",
        "mean_total_omnet_evaluations",
    ]

    write_csv(
        args.out / "convergence_per_run.csv",
        all_rows,
        per_run_fields,
    )
    write_csv(
        args.out / "convergence_summary.csv",
        summaries,
        summary_fields,
    )

    print()
    print("=" * 80)
    print(
        f"OMNeT++ EVALUATIONS TO REACH "
        f"{args.fraction * 100:.1f}% OF FINAL IMPROVEMENT"
    )
    print("=" * 80)
    print(
        "PSO/Hybrid baseline = best PDR after first full simulated population.\n"
        "Naive-Sim baseline  = best PDR after the same number of initial "
        "high-fidelity evaluations as paired PSO-Sim.\n"
        f"Hybrid OMNeT++ detection threshold = {args.sim_time_threshold:g} s."
    )
    print()

    for s in summaries:
        print(
            f"{s['method']:10s} "
            f"n={s['runs']:2d}  "
            f"mean={s['mean_evaluations']:.2f}  "
            f"median={s['median_evaluations']:.2f}  "
            f"SD={s['std_deviation']:.2f}  "
            f"range=[{s['min_evaluations']}, {s['max_evaluations']}]"
        )

    print()
    print("LaTeX-ready rows:")
    print()
    for s in summaries:
        print(
            f"{s['method']:10s} & "
            f"{s['mean_evaluations']:.2f} & "
            f"{s['median_evaluations']:.2f} & "
            f"{s['std_deviation']:.2f} \\\\"
        )

    print()
    print("NOTE:")
    print(
        "For Naive-Sim, this is a best-so-far threshold, not PSO-style "
        "algorithmic convergence."
    )
    print()
    print(f"Per-run CSV: {args.out / 'convergence_per_run.csv'}")
    print(f"Summary CSV: {args.out / 'convergence_summary.csv'}")
    print()


if __name__ == "__main__":
    main()
