#!/usr/bin/env python3

"""
Summarize final PDR performance and runtime from the five experiment folders.

Expected log semantics (matching the previous comparison scripts):

- PSO-Sim:
    Final global best fitness = actual OMNeT++ PDR
- Naive-Sim:
    Final global best fitness = actual OMNeT++ PDR
- Naive-RF:
    Final global best fitness = final OMNeT++ verification PDR
    last "new best fitness" = RF-predicted PDR of the selected solution
- PSO-RF:
    explicit final OMNeT++ verification line = actual PDR
    Final global best fitness = RF-predicted PDR
- Hybrid:
    explicit final OMNeT++ verification line = actual PDR
    no predicted PDR is reported in the requested table

Runtime:
- Prefer the last "Final Evaluation Time: X seconds" in each log.
- If it is absent, sum all "Evaluation Time: X seconds" entries.

The script prints:
1. Mean actual PDR +/- sample standard deviation
2. Mean predicted PDR for methods with a final surrogate prediction
3. Final-solution prediction MAE = mean(|actual PDR - predicted PDR|)
4. Mean signed prediction error = mean(actual PDR - predicted PDR)
5. Total runtime per method and grand total
6. LaTeX-ready table rows
7. CSV files with per-run and summary values

Example:

python3 final_performance_summary.py \\
    --pso-sim logs/pso_sim \\
    --naive-sim logs/naive_sim \\
    --pso-rf logs/pso_rf \\
    --naive-rf logs/naive_rf \\
    --hybrid logs/hybrid \\
    --expected 25 \\
    --out final_summary
"""

from pathlib import Path
import argparse
import csv
import re
import statistics
import sys

NUM = r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?"

FINAL_FITNESS_RE = re.compile(
    rf"^\s*Final\s+global\s+best\s+fitness:\s*({NUM})\s*$",
    re.IGNORECASE | re.MULTILINE,
)

NEW_BEST_FITNESS_RE = re.compile(
    rf"^\s*new\s+best\s+fitness:\s*({NUM})\s*$",
    re.IGNORECASE | re.MULTILINE,
)

# Optional explicit prediction labels, if present in a future/newer logger.
PREDICTED_PDR_PATTERNS = [
    re.compile(
        rf"^\s*(?:Final\s+)?(?:RF\s+)?Predicted\s+(?:fitness|PDR):\s*({NUM})\s*$",
        re.IGNORECASE | re.MULTILINE,
    ),
    re.compile(
        rf"^\s*Prediction\s+(?:fitness|PDR):\s*({NUM})\s*$",
        re.IGNORECASE | re.MULTILINE,
    ),
]

# Same explicit final-simulation patterns used by the PDR-distance script.
VALIDATED_PDR_PATTERNS = [
    re.compile(
        rf"^\s*Simulation of the best (?:surrogate )?solution results:\s*({NUM})",
        re.IGNORECASE | re.MULTILINE,
    ),
    re.compile(
        rf"^\s*(?:Final|Best)\s+"
        rf"(?:(?:global|selected)\s+best\s+)?"
        rf"(?:actual|simulated|simulation)\s+"
        rf"(?:fitness|PDR):\s*({NUM})",
        re.IGNORECASE | re.MULTILINE,
    ),
    re.compile(
        rf"^\s*(?:Actual|Verified|Validation)\s+"
        rf"(?:simulation\s+)?(?:fitness|PDR):\s*({NUM})",
        re.IGNORECASE | re.MULTILINE,
    ),
    re.compile(
        rf"^\s*Simulation of (?:the )?final "
        rf"(?:best )?(?:solution|layout) "
        rf"(?:results|fitness|PDR):\s*({NUM})",
        re.IGNORECASE | re.MULTILINE,
    ),
]

FINAL_EVAL_TIME_RE = re.compile(
    rf"^\s*Final\s+Evaluation\s+Time:\s*({NUM})\s*seconds\s*$",
    re.IGNORECASE | re.MULTILINE,
)

EVAL_TIME_RE = re.compile(
    rf"^\s*Evaluation\s+Time:\s*({NUM})\s*seconds\s*$",
    re.IGNORECASE | re.MULTILINE,
)

METHODS = [
    ("PSO", "PSO-Sim", "pso_sim"),
    ("Naive", "Naive-Sim", "naive_sim"),
    ("PSO--RF", "PSO-RF", "pso_rf"),
    ("Naive--RF", "Naive-RF", "naive_rf"),
    ("Hybrid", "Hybrid", "hybrid"),
]


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def validate_pdr(value: float, source: str) -> float:
    if not 0.0 <= value <= 1.0:
        raise ValueError(f"PDR outside [0,1] in {source}: {value}")
    return value


def last_match_value(pattern: re.Pattern, text: str):
    matches = list(pattern.finditer(text))
    if not matches:
        return None
    return float(matches[-1].group(1))


def final_logged_fitness(text: str):
    return last_match_value(FINAL_FITNESS_RE, text)


def explicit_simulated_pdr(text: str, extra_pattern=None):
    patterns = list(VALIDATED_PDR_PATTERNS)
    if extra_pattern is not None:
        patterns.insert(0, extra_pattern)

    matches = []
    for pattern in patterns:
        for match in pattern.finditer(text):
            matches.append((match.start(), float(match.group(1)), match.group(0).strip()))

    if not matches:
        return None, None

    _, value, label = max(matches, key=lambda item: item[0])
    return validate_pdr(value, label), label


def actual_pdr(path: Path, internal_method: str, extra_pattern=None):
    text = read_text(path)

    if internal_method in ("PSO-Sim", "Naive-Sim", "Naive-RF"):
        value = final_logged_fitness(text)
        if value is None:
            raise ValueError("missing 'Final global best fitness'")
        return validate_pdr(value, path.name), "Final global best fitness"

    if internal_method in ("PSO-RF", "Hybrid"):
        value, source = explicit_simulated_pdr(text, extra_pattern)
        if value is None:
            raise ValueError(
                "missing explicit final OMNeT++ verification PDR; "
                "use --actual-pdr-regex if your logger uses another label"
            )
        return value, source

    raise ValueError(f"unknown method: {internal_method}")


def explicit_predicted_pdr(text: str):
    matches = []
    for pattern in PREDICTED_PDR_PATTERNS:
        for match in pattern.finditer(text):
            matches.append((match.start(), float(match.group(1))))
    if not matches:
        return None
    _, value = max(matches, key=lambda item: item[0])
    return value


def predicted_pdr(path: Path, internal_method: str):
    text = read_text(path)

    # If the logger has an explicit prediction label, prefer it.
    explicit = explicit_predicted_pdr(text)
    if explicit is not None:
        return validate_pdr(explicit, f"explicit prediction in {path.name}"), "explicit prediction label"

    if internal_method == "PSO-RF":
        # In PSO-RF, Final global best fitness is the surrogate fitness;
        # the actual final PDR is obtained from a separate OMNeT++ verification line.
        value = final_logged_fitness(text)
        if value is None:
            raise ValueError("missing predicted 'Final global best fitness'")
        return validate_pdr(value, path.name), "Final global best fitness"

    if internal_method == "Naive-RF":
        # In Naive-RF, final global best fitness is the final simulation,
        # while 'new best fitness' entries are RF predictions.
        value = last_match_value(NEW_BEST_FITNESS_RE, text)
        if value is None:
            raise ValueError("missing predicted 'new best fitness'")
        return validate_pdr(value, path.name), "last new best fitness"

    if internal_method == "Hybrid":
        # For Hybrid, only use a prediction if the logger explicitly labels it.
        # We deliberately do NOT infer it from Final global best fitness because
        # that value may be simulation-confirmed depending on the implementation.
        return None, None

    return None, None


def runtime_seconds(path: Path):
    text = read_text(path)

    final_times = list(FINAL_EVAL_TIME_RE.finditer(text))
    if final_times:
        return float(final_times[-1].group(1)), "Final Evaluation Time"

    eval_times = [float(m.group(1)) for m in EVAL_TIME_RE.finditer(text)]
    if eval_times:
        return sum(eval_times), f"sum of {len(eval_times)} Evaluation Time entries"

    raise ValueError("missing runtime ('Final Evaluation Time' or 'Evaluation Time')")


def ordered_logs(folder: Path):
    if not folder.is_dir():
        raise ValueError(f"not a directory: {folder}")

    logs = sorted(folder.rglob("*.log"), key=lambda p: (p.name, str(p)))
    if not logs:
        raise ValueError(f"no .log files found under {folder}")
    return logs


def fmt_time(seconds: float) -> str:
    if seconds < 60:
        return f"{seconds:.2f} s"
    if seconds < 3600:
        return f"{seconds / 60:.2f} min"
    return f"{seconds / 3600:.2f} h"


def sample_sd(values):
    if len(values) < 2:
        return 0.0
    return statistics.stdev(values)


def main():
    parser = argparse.ArgumentParser(
        description=__doc__,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    parser.add_argument("--pso-sim", type=Path, required=True)
    parser.add_argument("--naive-sim", type=Path, required=True)
    parser.add_argument("--pso-rf", type=Path, required=True)
    parser.add_argument("--naive-rf", type=Path, required=True)
    parser.add_argument("--hybrid", type=Path, required=True)
    parser.add_argument("--expected", type=int, default=None,
                        help="Require exactly N logs for every method, e.g. 25.")
    parser.add_argument("--out", type=Path, default=Path("final_summary"))
    parser.add_argument(
        "--actual-pdr-regex",
        type=str,
        default=None,
        help=(
            "Optional regex for the explicit final OMNeT++ PDR in PSO-RF/Hybrid. "
            "It must contain exactly one capturing group for the numeric PDR."
        ),
    )

    args = parser.parse_args()

    extra_pattern = None
    if args.actual_pdr_regex:
        try:
            extra_pattern = re.compile(
                args.actual_pdr_regex,
                re.IGNORECASE | re.MULTILINE,
            )
        except re.error as exc:
            parser.error(f"invalid --actual-pdr-regex: {exc}")
        if extra_pattern.groups != 1:
            parser.error("--actual-pdr-regex must contain exactly one capturing group")

    args.out.mkdir(parents=True, exist_ok=True)

    per_run_rows = []
    summary_rows = []
    grand_total_seconds = 0.0

    print("\nFINAL PERFORMANCE + RUNTIME SUMMARY\n")

    for display_name, internal_method, arg_name in METHODS:
        folder = getattr(args, arg_name)

        try:
            logs = ordered_logs(folder)
        except ValueError as exc:
            raise SystemExit(f"{display_name}: {exc}")

        if args.expected is not None and len(logs) != args.expected:
            raise SystemExit(
                f"{display_name}: expected {args.expected} logs, found {len(logs)}"
            )

        actual_values = []
        predicted_values = []
        prediction_abs_errors = []
        prediction_signed_errors = []
        runtime_values = []

        for run_number, log_path in enumerate(logs, start=1):
            try:
                actual, actual_source = actual_pdr(
                    log_path, internal_method, extra_pattern
                )
            except ValueError as exc:
                raise SystemExit(f"{display_name}: {log_path.name}: {exc}")

            prediction = None
            prediction_source = None
            if internal_method in ("PSO-RF", "Naive-RF", "Hybrid"):
                try:
                    prediction, prediction_source = predicted_pdr(
                        log_path, internal_method
                    )
                except ValueError as exc:
                    raise SystemExit(f"{display_name}: {log_path.name}: {exc}")

            try:
                seconds, runtime_source = runtime_seconds(log_path)
            except ValueError as exc:
                raise SystemExit(f"{display_name}: {log_path.name}: {exc}")

            actual_values.append(actual)
            signed_error = None
            abs_error = None
            if prediction is not None:
                predicted_values.append(prediction)
                signed_error = actual - prediction
                abs_error = abs(signed_error)
                prediction_signed_errors.append(signed_error)
                prediction_abs_errors.append(abs_error)
            runtime_values.append(seconds)

            per_run_rows.append({
                "method": display_name.replace("--", "-"),
                "run": run_number,
                "log": str(log_path),
                "actual_pdr": actual,
                "actual_pdr_source": actual_source,
                "predicted_pdr": "" if prediction is None else prediction,
                "predicted_pdr_source": "" if prediction_source is None else prediction_source,
                "prediction_error_actual_minus_predicted": "" if signed_error is None else signed_error,
                "absolute_prediction_error": "" if abs_error is None else abs_error,
                "runtime_seconds": seconds,
                "runtime_source": runtime_source,
            })

        mean_actual = statistics.mean(actual_values)
        sd_actual = sample_sd(actual_values)
        mean_pred = statistics.mean(predicted_values) if predicted_values else None
        final_solution_mae = (
            statistics.mean(prediction_abs_errors) if prediction_abs_errors else None
        )
        mean_signed_prediction_error = (
            statistics.mean(prediction_signed_errors) if prediction_signed_errors else None
        )
        total_seconds = sum(runtime_values)
        mean_runtime = statistics.mean(runtime_values)
        grand_total_seconds += total_seconds

        summary_rows.append({
            "method": display_name.replace("--", "-"),
            "runs": len(logs),
            "mean_actual_pdr": mean_actual,
            "sd_actual_pdr": sd_actual,
            "mean_predicted_pdr": "" if mean_pred is None else mean_pred,
            "final_solution_prediction_mae": "" if final_solution_mae is None else final_solution_mae,
            "mean_prediction_error_actual_minus_predicted": "" if mean_signed_prediction_error is None else mean_signed_prediction_error,
            "prediction_pairs": len(prediction_abs_errors),
            "total_runtime_seconds": total_seconds,
            "mean_runtime_seconds_per_run": mean_runtime,
        })

        pred_text = "--" if mean_pred is None else f"{mean_pred:.6f}"
        mae_text = "--" if final_solution_mae is None else f"{final_solution_mae:.6f}"
        signed_text = (
            "--" if mean_signed_prediction_error is None
            else f"{mean_signed_prediction_error:.6f}"
        )
        print(
            f"{display_name:10s}  n={len(logs):2d}  "
            f"Actual={mean_actual:.6f} +/- {sd_actual:.6f}  "
            f"Predicted={pred_text:>8s}  "
            f"Final-MAE={mae_text:>8s}  "
            f"MeanErr(A-P)={signed_text:>9s}  "
            f"Total time={fmt_time(total_seconds)}  "
            f"Mean/run={fmt_time(mean_runtime)}"
        )

    print("\nGrand total runtime across all methods:", fmt_time(grand_total_seconds))
    print(f"Grand total seconds: {grand_total_seconds:.6f}")

    print("\nFINAL-SOLUTION PREDICTION ERROR\n")
    print("MAE = mean(|actual PDR - predicted PDR|) across final selected solutions\n")
    for row in summary_rows:
        mae = row["final_solution_prediction_mae"]
        signed = row["mean_prediction_error_actual_minus_predicted"]
        if mae == "":
            continue
        print(
            f"{row['method']:10s}  pairs={row['prediction_pairs']:2d}  "
            f"MAE={mae:.6f} ({mae * 100:.3f} pp)  "
            f"Mean actual-predicted={signed:.6f} ({signed * 100:.3f} pp)"
        )

    print("\nLATEX-READY PERFORMANCE ROWS\n")
    for row in summary_rows:
        method = row["method"].replace("PSO-RF", "PSO--RF").replace("Naive-RF", "Naive--RF")
        pred = row["mean_predicted_pdr"]
        pred_text = "--" if pred == "" else f"{pred:.6f}"
        print(
            f"{method:<10s} & "
            f"{row['mean_actual_pdr']:.6f} $\\pm$ {row['sd_actual_pdr']:.6f} & "
            f"{pred_text} \\\\" 
        )

    print("\nLATEX-READY RUNTIME ROWS\n")
    for row in summary_rows:
        method = row["method"].replace("PSO-RF", "PSO--RF").replace("Naive-RF", "Naive--RF")
        print(
            f"{method:<10s} & "
            f"{row['total_runtime_seconds']:.2f} & "
            f"{row['mean_runtime_seconds_per_run']:.2f} \\\\" 
        )

    per_run_path = args.out / "per_run_values.csv"
    with per_run_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=per_run_rows[0].keys())
        writer.writeheader()
        writer.writerows(per_run_rows)

    summary_path = args.out / "summary.csv"
    with summary_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=summary_rows[0].keys())
        writer.writeheader()
        writer.writerows(summary_rows)

    print(f"\nWrote: {per_run_path}")
    print(f"Wrote: {summary_path}\n")


if __name__ == "__main__":
    main()
