#!/bin/bash

set -e

# ============================================================
# OMNeT++ / INET environment
# ============================================================

OMNET_ROOT="$HOME/sim/omnetpp/omnetpp-6.0.3"
export INET_ROOT="/home/gui/sim/inet"

# setenv is normally sourced from the OMNeT++ directory
pushd "$OMNET_ROOT" > /dev/null
. setenv
popd > /dev/null

# Optional sanity checks
if ! command -v opp_run > /dev/null 2>&1; then
    echo "ERROR: opp_run not found"
    exit 1
fi

if [ ! -d "$INET_ROOT" ]; then
    echo "ERROR: INET_ROOT does not exist: $INET_ROOT"
    exit 1
fi


# ============================================================
# Experiment
# ============================================================

RUN_DIR="$(pwd)"

SCRIPT_NAME="$(basename "$0")"
SCRIPT_BASE="${SCRIPT_NAME%.*}"

OUTPUT_DIR="$RUN_DIR/$SCRIPT_BASE"
OUTPUT_DIR_NAIVE="$RUN_DIR/${SCRIPT_BASE}_naive"


echo "=== Building project ==="

cd ../..

cmake -S  . -B build
cmake --build build --clean-first -j

source .venv/bin/activate

cd build

#./surrogated-assisted-optimizer pso 3_relays/15 0 20 0.8 1.7 1.3
cd "$RUN_DIR"

OUTPUT_PLOT="$OUTPUT_DIR/3_relays-15.png"

python3 ../plot.py "$OUTPUT_PLOT"

cd ../..
cd build

./surrogated-assisted-optimizer naive 3_relays/15 0 400

cd "$RUN_DIR"

OUTPUT_PLOT_NAIVE="$OUTPUT_DIR_NAIVE/3_relays-15.png"

python3 ../plot.py "$OUTPUT_PLOT_NAIVE"
